package com.example.snapchat_v201.adapterView

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.snapchat_v201.R
import com.example.snapchat_v201.databinding.ItemsBinding
import com.example.snapchat_v201.models.ModelPublicacion
import com.squareup.picasso.Picasso


class AdapterView(
    private var listaPublicaciones: List<ModelPublicacion>,
    private val onActualizarClick: (ModelPublicacion) -> Unit,
    private val onEliminarClick: (ModelPublicacion) -> Unit
) : RecyclerView.Adapter<AdapterView.AdapaterPublHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AdapaterPublHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.items, parent, false)
        return AdapaterPublHolder(view)
    }
//    Crea la “plantilla” visual para cada elemento del RecyclerView usando el archivo XML item_transmision.
//    Aquí usa inflater para convertir el XML en un objeto View.

    override fun getItemCount(): Int = listaPublicaciones.size
//    Le dice al RecyclerView cuántos elementos hay en la lista.



    override fun onBindViewHolder(holder: AdapaterPublHolder, position: Int) {
        holder.inicializar(listaPublicaciones[position])
    }
    //rellena la vista de la tarjeta con los datos de esa publicación

    inner class AdapaterPublHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val binding = ItemsBinding.bind(itemView)

        fun inicializar(item: ModelPublicacion) {
            Picasso.get()
                .load(item.imagen_publicacion)
                .into(binding.imagenPublicacion)
            binding.titulo.text = item.titulo
            binding.descripcion.text = item.descripcion

            binding.btnActualizar.setOnClickListener {
                onActualizarClick(item)
            }

            binding.btnEliminar.setOnClickListener {
                onEliminarClick(item)
            }
        }
    }
}