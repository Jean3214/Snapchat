package com.example.snapchat_v201.models

data class ModelPublicacion (
    var imagen_publicacion: String,
    var titulo: String,
    var descripcion:String,
)

object DataModelUsuarioDelModelo_ {
    val dataSet: MutableList<ModelPublicacion> = mutableListOf(

    )
}