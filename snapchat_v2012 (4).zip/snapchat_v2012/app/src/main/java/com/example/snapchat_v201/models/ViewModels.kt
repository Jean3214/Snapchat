package com.example.snapchat_v201.models

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class ViewModelUsuario: ViewModel() {
    private val _dataList : MutableLiveData<MutableList<ModelPublicacion>> =
        MutableLiveData(mutableListOf())
    val dataList: MutableLiveData<MutableList<ModelPublicacion>>
        get() = _dataList
    fun addDataList(mData: MutableList<ModelPublicacion>){
        val currentList = dataList.value?:mutableListOf()
        currentList.addAll(mData)
        dataList.postValue(currentList)
    }
    fun addData(mData:ModelPublicacion){
        val currentList = dataList.value?:mutableListOf()
        currentList.add(mData)
        dataList.postValue(currentList)
    }
    fun updateData(mData: ModelPublicacion, position: Int){
        val currentList = dataList.value?:mutableListOf()
        currentList.set(position, mData)
        dataList.postValue(currentList)
    }
    fun deleteData(position: Int){
        val currentList = dataList.value?:mutableListOf()
        currentList.removeAt(position)
        dataList.postValue (currentList)
    }
}