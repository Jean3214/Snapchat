package com.example.snapchat_v201

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.snapchat_v201.databinding.ActivityMainBinding
import com.example.snapchat_v201.databinding.ActivityRegistroBinding

data class Usuario(val nombre: String, val contraseña: String)

class MainActivity : AppCompatActivity() {
    companion object { val lista_usuarios = mutableListOf<Usuario>(
        Usuario("pinillita","P12345")//predeterminado
    ) }

    private lateinit var binding: ActivityMainBinding
     val usuario: String? = null
     val password: String? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
       binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        btn_accion_R()
        validador()
    }

    private fun validador() {
        binding.btnLogin.setOnClickListener {
        val usuario = intent.getStringExtra("usuario")
        val password = intent.getStringExtra("password")

        val Lgusuario = binding.edUsuario.text.toString()
        val Lgpassword = binding.edPassword.text.toString()
        if (Lgusuario.isNullOrEmpty() || Lgpassword.isNullOrEmpty()) {
            // Validamos campos vacios
            if (!usuario.isNullOrEmpty() && !password.isNullOrEmpty()) {
                val nuevoUsuario = Usuario(usuario, password)//Agregada de datos
                lista_usuarios.add(nuevoUsuario)
            }
    }else if(Lgusuario != usuario && Lgpassword != password){
            Toast.makeText(this, "Campos incorrectos", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, Registro::class.java)
            startActivity(intent)
            finish()
    }else {
            val intent = Intent(this, principal::class.java)
            intent.putExtra("USERNAME", usuario )
            startActivity(intent)
            finish()
    }
    }
    }



    private fun btn_accion_R() {
        binding.btnRegistar.setOnClickListener {
            val intent = Intent(this, Registro::class.java)
            startActivity(intent)
        }
    }
}