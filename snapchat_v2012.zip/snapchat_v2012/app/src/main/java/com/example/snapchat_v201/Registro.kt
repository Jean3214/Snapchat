package com.example.snapchat_v201

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import java.util.Calendar
import androidx.core.view.WindowInsetsCompat
import com.example.snapchat_v201.databinding.ActivityRegistroBinding

class Registro : AppCompatActivity() {

    private lateinit var binding: ActivityRegistroBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegistroBinding.inflate(layoutInflater)
        setContentView(binding.root)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        fecha_calender()
        retroceder()
        registrarse()
    }

    private fun registrarse() {
        binding.registrarseBtnR.setOnClickListener {
            val usuario = binding.edUsuarioR.text.toString().trim()
            val password = binding.edPasswordR.text.toString().trim()
            val email = binding.edEmail.text.toString().trim()
            val fecha = binding.edFechaR.text.toString().trim()

            if (usuario.isEmpty() || password.isEmpty() || email.isEmpty() || fecha.isEmpty()) {
                Toast.makeText(this, "Campos vacíos o incorrectos", Toast.LENGTH_SHORT).show()
            } else if (password.length < 6) {
                Toast.makeText(this, "La contraseña debe tener al menos 6 caracteres", Toast.LENGTH_SHORT).show()
            } else {
                val intent = Intent(this, MainActivity::class.java)
                intent.putExtra("usuario", usuario)
                intent.putExtra("password", password)
                startActivity(intent)
                finish()
            }
        }
    }


    private fun retroceder() {
        binding.retroceder.setOnClickListener {
            val intent = Intent(this,MainActivity::class.java)
            startActivity(intent)
            finish()
        }
    }

    private fun fecha_calender() {
        // Desactiva la edición directa del campo (evita teclado)
        binding.edFechaR.keyListener = null

// Abre el calendario al hacer clic
        binding.edFechaR.setOnClickListener {
            val cal = Calendar.getInstance()
            val datePicker = DatePickerDialog(
                this, // Cambia a 'requireContext()' si usas Fragment
                { _, year, month, dayOfMonth ->
                    // Ajusta la fecha para mostrar siempre dos dígitos con String.format
                    val formattedDate = String.format("%02d/%02d/%04d", dayOfMonth, month + 1, year)
                    binding.edFechaR.setText(formattedDate)
                },
                cal.get(Calendar.YEAR),
                cal.get(Calendar.MONTH),
                cal.get(Calendar.DAY_OF_MONTH)
            )
            datePicker.show()
        }
    }
}

